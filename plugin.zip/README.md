OS | Stable Channel | Pre-release Channel
-- | ------ | ---------------------------
Linux | -/- | -/-
macOS | ![macOS Stable Status Badge](https://guillermooo.visualstudio.com/_apis/public/build/definitions/986e7fe3-0d02-4c0e-b893-118ef33de6d1/2/badge) | -/-
Windows | -/- | ![Windows Dev Status Badge](https://guillermooo.visualstudio.com/_apis/public/build/definitions/986e7fe3-0d02-4c0e-b893-118ef33de6d1/1/badge)

**Sublime Six** is an advanced Vim emulator implemented entirely as a Python plugin. It works on Linux, macOS and Windows.

For more information, see the [Sublime Six](http://www.sublimesix.com) web site.

You can evaluate Sublime Six without any limits, but for continued use you must purchase a license.

For any questions, contact hi@sublimesix.com.

We are on [Twitter](https://twitter.com/sublimesix)!

# Activate Sublime Text commands.
from .commands import *

# Register Vim commands.
from .lib import motions
from .lib import operators
from .lib import ex_commands
